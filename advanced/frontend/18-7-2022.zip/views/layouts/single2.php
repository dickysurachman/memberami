<!doctype html>
<html lang="en-US">

<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>

	<?php 
		include("head22.php")
	?>
</head>
<body class="envato_tk_templates-template envato_tk_templates-template-elementor_header_footer single single-envato_tk_templates postid-922 qodef-qi--no-touch qi-addons-for-elementor-1.5.3 elementor-default elementor-template-full-width elementor-kit-7 elementor-page elementor-page-922">

		<?php

			include ("header2.php");
		?>
								
					
	<div data-elementor-type="wp-post" data-elementor-id="922" class="elementor elementor-922">
	<section class="elementor-section elementor-top-section elementor-element elementor-element-51c084d elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="51c084d" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
	<div class="elementor-background-overlay"></div>
	<div class="elementor-container elementor-column-gap-default">
	<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-3eb656b elementor-invisible" data-id="3eb656b" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;fadeInLeft&quot;}">
	<div class="elementor-widget-wrap elementor-element-populated">
	<div class="elementor-element elementor-element-887e080 elementor-widget elementor-widget-heading" data-id="887e080" data-element_type="widget" data-widget_type="heading.default">
	<div class="elementor-widget-container">
	<h6 class="elementor-heading-title elementor-size-default">Data & Analytics</h6>
	</div>
	</div>
				<div class="elementor-element elementor-element-870e602 elementor-widget elementor-widget-heading" data-id="870e602" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h1 class="elementor-heading-title elementor-size-default">The power of computers to intelligent machines.</h1>		</div>
				</div>
				<div class="elementor-element elementor-element-31cdd6c elementor-widget elementor-widget-text-editor" data-id="31cdd6c" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
						<p>Justo tincidunt natoque at mauris senectus. Semper inceptos aliquam ex parturient donec ante. Etiam vestibulum iaculis ullamcorper fusce malesuada scelerisque condimentum laoreet.</p>						</div>
				</div>
				<div class="elementor-element elementor-element-fba5fa9 elementor-widget elementor-widget-button" data-id="fba5fa9" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a href="#" class="elementor-button-link elementor-button elementor-size-md" role="button">
						<span class="elementor-button-content-wrapper">
							<span class="elementor-button-icon elementor-align-icon-right">
				<i aria-hidden="true" class="fas fa-chevron-right"></i>			</span>
						<span class="elementor-button-text">Discover More</span>
		</span>
					</a>
		</div>
				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-e37069a elementor-invisible" data-id="e37069a" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;fadeInRight&quot;}">
				<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-8530ade elementor-widget elementor-widget-image" data-id="8530ade" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
				<img width="720" height="581" src="wp-content/uploads/sites/26/2021/12/img_2.png" class="attachment-large size-large" alt="" loading="lazy" srcset="wp-content/uploads/sites/26/2021/12/img_2.png 720w, wp-content/uploads/sites/26/2021/12/img_2-300x242.png 300w" sizes="(max-width: 720px) 100vw, 720px" />															
				</div>
				</div>
				</div>
		</div>
		</div>
	</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-e6b0a91 elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-invisible" data-id="e6b0a91" data-element_type="section" data-settings="{&quot;animation&quot;:&quot;fadeInUp&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-8d6ea5d" data-id="8d6ea5d" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<section class="elementor-section elementor-inner-section elementor-element elementor-element-7f44e14 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="7f44e14" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-0f01c54 elementor-invisible" data-id="0f01c54" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;fadeInDown&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-c841177 elementor-widget-mobile__width-inherit ekit-equal-height-enable elementor-widget elementor-widget-elementskit-icon-box" data-id="c841177" data-element_type="widget" data-widget_type="elementskit-icon-box.default">
				<div class="elementor-widget-container">
			<div class="ekit-wid-con" >        <!-- link opening -->
                <!-- end link opening -->

        <div class="elementskit-infobox text-center text-center icon-top-align elementor-animation-   ">
                            <div class="elementskit-box-header">
                <div class="elementskit-info-box-icon ">
                    <img width="77" height="88" src="wp-content/uploads/sites/26/2021/12/icon_4.png" class="attachment- size-" alt="" loading="lazy" />                </div>
          </div>
                <div class="box-body">
                            <div class="elementskit-info-box-title">
                    Automate workflows.                </div>
                        		  Interdum platea potenti ad efficitur iaculis inceptos sodales eleifend venenatis luctus semper                                        <div class="box-footer disable_hover_button">
                    <div class="btn-wraper">
                                                            <a href="#"  target="_self" rel="" class="elementskit-btn whitespace--normal elementor-animation-">
                                        Learn More
                                        <i aria-hidden="true" class="fas fa-chevron-right"></i>
                                    </a>
                                                        </div>
                </div>
                    </div>
        
        <div class="icon-hover">
            <i aria-hidden="true" class="icon icon-right-mark"></i>        </div>

        
        
                </div>
        </div>		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-1a2c6fb elementor-invisible" data-id="1a2c6fb" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;fadeInDown&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-29fc37f elementor-widget-mobile__width-inherit ekit-equal-height-enable elementor-widget elementor-widget-elementskit-icon-box" data-id="29fc37f" data-element_type="widget" data-widget_type="elementskit-icon-box.default">
				<div class="elementor-widget-container">
			<div class="ekit-wid-con" >        

        <div class="elementskit-infobox text-center text-center icon-top-align elementor-animation-   ">
                            <div class="elementskit-box-header">
                <div class="elementskit-info-box-icon ">
                    <img width="77" height="88" src="wp-content/uploads/sites/26/2021/12/icon_6.png" class="attachment- size-" alt="" loading="lazy" />                
                </div>
          </div>
                <div class="box-body">
                            <div class="elementskit-info-box-title">
                    Transform data for new insights.                </div>
                        		  Interdum platea potenti ad efficitur iaculis inceptos sodales eleifend venenatis luctus semper                                        <div class="box-footer disable_hover_button">
                    <div class="btn-wraper">
                                                            <a href="#"  target="_self" rel="" class="elementskit-btn whitespace--normal elementor-animation-">
                                        Learn More
                                        <i aria-hidden="true" class="fas fa-chevron-right"></i>
                                    </a>
                                                        </div>
                </div>
                    </div>
        
        <div class="icon-hover">
            <i aria-hidden="true" class="icon icon-right-mark"></i>        </div>

        
        
                </div>
        </div>		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-60fe54a elementor-invisible" data-id="60fe54a" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;fadeInDown&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-69104c4 elementor-widget-mobile__width-inherit ekit-equal-height-enable elementor-widget elementor-widget-elementskit-icon-box" data-id="69104c4" data-element_type="widget" data-widget_type="elementskit-icon-box.default">
				<div class="elementor-widget-container">
			<div class="ekit-wid-con" >        <!-- link opening -->
                <!-- end link opening -->

        <div class="elementskit-infobox text-center text-center icon-top-align elementor-animation-   ">
                            <div class="elementskit-box-header">
                <div class="elementskit-info-box-icon ">
                    <img width="77" height="88" src="wp-content/uploads/sites/26/2021/12/icon_5.png" class="attachment- size-" alt="" loading="lazy" />                </div>
          </div>
                <div class="box-body">
                            <div class="elementskit-info-box-title">
                    Fast response times.                </div>
                        		  Interdum platea potenti ad efficitur iaculis inceptos sodales eleifend venenatis luctus semper                                        <div class="box-footer disable_hover_button">
                    <div class="btn-wraper">
                                                            <a href="#"  target="_self" rel="" class="elementskit-btn whitespace--normal elementor-animation-">
                                        Learn More
                                        <i aria-hidden="true" class="fas fa-chevron-right"></i>
                                    </a>
                                                        </div>
                </div>
                    </div>
        
        <div class="icon-hover">
            <i aria-hidden="true" class="icon icon-right-mark"></i>        </div>

        
        
                </div>
        </div>		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-4ba7435 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="4ba7435" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-05ec370 elementor-invisible" data-id="05ec370" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;fadeInDown&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-e26db15 elementor-widget-mobile__width-inherit ekit-equal-height-enable elementor-widget elementor-widget-elementskit-icon-box" data-id="e26db15" data-element_type="widget" data-widget_type="elementskit-icon-box.default">
				<div class="elementor-widget-container">
			<div class="ekit-wid-con" >        <!-- link opening -->
                <!-- end link opening -->

        <div class="elementskit-infobox text-left text- icon-lef-right-aligin elementor-animation-   ">
                        <div class="box-body">
                            <div class="elementskit-info-box-title">
                    Shine a light on dark data.                </div>
                        		  Pretium enim gravida mollis quam justo penatibus ad in si vehicula nulla. Porta est cras eros congue pellentesque vitae cursus faucibus mi quis ultrices. Quis litora mattis enim quam felis lacinia consectetuer fermentum odio. Feugiat magna semper pellentesque lacinia primis. Amet auctor non sem ultrices proin habitasse ad sollicitudin ex facilisi quam.                                        <div class="box-footer disable_hover_button">
                    <div class="btn-wraper">
                                                            <a href="#"  target="_self" rel="" class="elementskit-btn whitespace--normal elementor-animation-">
                                        Learn More
                                        <i aria-hidden="true" class="fas fa-chevron-right"></i>
                                    </a>
                                                        </div>
                </div>
                    </div>
        
        <div class="icon-hover">
            <i aria-hidden="true" class="icon icon-right-mark"></i>        </div>

        
        
                </div>
        </div>		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-44c2200 elementor-invisible" data-id="44c2200" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;fadeInDown&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-6860ae9 elementor-widget elementor-widget-image" data-id="6860ae9" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
					<img width="1080" height="608" src="wp-content/uploads/sites/26/2021/12/circuit-board-and-ai-micro-processor-artificial-intelligence-of-digital-human-3d-render.jpg" class="attachment-full size-full" alt="Circuit board and AI micro processor, Artificial intelligence of digital human. 3d render" loading="lazy" srcset="wp-content/uploads/sites/26/2021/12/circuit-board-and-ai-micro-processor-artificial-intelligence-of-digital-human-3d-render.jpg 1080w, wp-content/uploads/sites/26/2021/12/circuit-board-and-ai-micro-processor-artificial-intelligence-of-digital-human-3d-render-300x169.jpg 300w, wp-content/uploads/sites/26/2021/12/circuit-board-and-ai-micro-processor-artificial-intelligence-of-digital-human-3d-render-1024x576.jpg 1024w, wp-content/uploads/sites/26/2021/12/circuit-board-and-ai-micro-processor-artificial-intelligence-of-digital-human-3d-render-768x432.jpg 768w, wp-content/uploads/sites/26/2021/12/circuit-board-and-ai-micro-processor-artificial-intelligence-of-digital-human-3d-render-1536x864.jpg 1536w, wp-content/uploads/sites/26/2021/12/circuit-board-and-ai-micro-processor-artificial-intelligence-of-digital-human-3d-render-800x450.jpg 800w" sizes="(max-width: 1080px) 100vw, 1080px" />											
				</div>
				</div>
					</div>
		</div>
							</div>
		</section>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-9701a79 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="9701a79" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
							<div class="elementor-background-overlay"></div>
							<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-ef6b8b5 elementor-invisible" data-id="ef6b8b5" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;fadeInLeft&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-0ebd34e elementor-widget elementor-widget-heading" data-id="0ebd34e" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h6 class="elementor-heading-title elementor-size-default">Why Choose Us</h6>		</div>
				</div>
				<div class="elementor-element elementor-element-5bf48b7 elementor-widget elementor-widget-heading" data-id="5bf48b7" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">With great power comes great productivity.</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-0e5ceeb ekit-equal-height-disable elementor-invisible elementor-widget elementor-widget-elementskit-icon-box" data-id="0e5ceeb" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeInRight&quot;}" data-widget_type="elementskit-icon-box.default">
				<div class="elementor-widget-container">
			<div class="ekit-wid-con" >        <!-- link opening -->
                <!-- end link opening -->

        <div class="elementskit-infobox text-left text-left icon-lef-right-aligin elementor-animation- media  ">
                    <div class="elementskit-box-header elementor-animation-">
                <div class="elementskit-info-box-icon  text-center">
                    <i aria-hidden="true" class="elementkit-infobox-icon icon icon-layers1"></i>
                </div>
          </div>
                        <div class="box-body">
                            <div class="elementskit-info-box-title">
                    Smart Solutions                </div>
                        		  Sollicitudin massa maecenas purus adipiscing egestas natoque fringilla odio ac sodales                                </div>
        
        
                </div>
        </div>		</div>
				</div>
				<div class="elementor-element elementor-element-5691e80 ekit-equal-height-disable elementor-invisible elementor-widget elementor-widget-elementskit-icon-box" data-id="5691e80" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeInRight&quot;}" data-widget_type="elementskit-icon-box.default">
				<div class="elementor-widget-container">
		<div class="ekit-wid-con" >        
		<!-- link opening -->
         <!-- end link opening -->

        <div class="elementskit-infobox text-left text-left icon-lef-right-aligin elementor-animation- media  ">
                    <div class="elementskit-box-header elementor-animation-">
                <div class="elementskit-info-box-icon  text-center">
                    <i aria-hidden="true" class="elementkit-infobox-icon icon icon-coins-2"></i>
                </div>
          </div>
           <div class="box-body">
               <div class="elementskit-info-box-title">Certified Expert</div>
               Sollicitudin massa maecenas purus adipiscing egestas natoque fringilla odio ac sodales                                
           </div>
        
        
                </div>
        </div>		</div>
				</div>
				<div class="elementor-element elementor-element-93273b9 ekit-equal-height-disable elementor-invisible elementor-widget elementor-widget-elementskit-icon-box" data-id="93273b9" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;fadeInRight&quot;}" data-widget_type="elementskit-icon-box.default">
				<div class="elementor-widget-container">
			<div class="ekit-wid-con" >        <!-- link opening -->
                <!-- end link opening -->

        <div class="elementskit-infobox text-left text-left icon-lef-right-aligin elementor-animation- media  ">
                    <div class="elementskit-box-header elementor-animation-">
                <div class="elementskit-info-box-icon  text-center">
                    <i aria-hidden="true" class="elementkit-infobox-icon icon icon-Support-2"></i>
                </div>
          </div>
                        <div class="box-body">
                            <div class="elementskit-info-box-title">
                    24/7 Support                </div>
                        		  Sollicitudin massa maecenas purus adipiscing egestas natoque fringilla odio ac sodales                                </div>
        
        
                </div>
        </div>		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-2e9afbd elementor-invisible" data-id="2e9afbd" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;fadeInRight&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-206bff3 elementor-widget elementor-widget-image" data-id="206bff3" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
															<img width="789" height="640" src="wp-content/uploads/sites/26/2021/12/img_1.png" class="attachment-full size-full" alt="" loading="lazy" srcset="wp-content/uploads/sites/26/2021/12/img_1.png 789w, wp-content/uploads/sites/26/2021/12/img_1-300x243.png 300w, wp-content/uploads/sites/26/2021/12/img_1-768x623.png 768w" sizes="(max-width: 789px) 100vw, 789px" />															</div>
				</div>
					</div>
		</div>
		</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-4dbecfa elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="4dbecfa" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
							<div class="elementor-background-overlay"></div>
							<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-d08e94d elementor-invisible" data-id="d08e94d" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;bounceInDown&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-dbb8ea8 elementor-widget elementor-widget-heading" data-id="dbb8ea8" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Artificial Intelligence is the new big thing in technology.</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-037ad21 elementor-widget elementor-widget-text-editor" data-id="037ad21" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.</p>						</div>
				</div>
				<div class="elementor-element elementor-element-5395e71 elementor-align-center elementor-widget elementor-widget-button" data-id="5395e71" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a href="#" class="elementor-button-link elementor-button elementor-size-md" role="button">
						<span class="elementor-button-content-wrapper">
						<span class="elementor-button-text">Get Started</span>
		</span>
					</a>
		</div>
				</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-c2db118 animated-slow elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-invisible" data-id="c2db118" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;animation&quot;:&quot;fadeIn&quot;}">
							<div class="elementor-background-overlay"></div>
							<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-03867f1" data-id="03867f1" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-dfea9e3 elementor-widget elementor-widget-heading" data-id="dfea9e3" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h6 class="elementor-heading-title elementor-size-default">Testimonial</h6>		</div>
				</div>
				<div class="elementor-element elementor-element-e582827 elementor-widget elementor-widget-heading" data-id="e582827" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">What they say</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-6a875ca elementor-widget elementor-widget-elementskit-testimonial" data-id="6a875ca" data-element_type="widget" data-widget_type="elementskit-testimonial.default">
				<div class="elementor-widget-container">
			<div class="ekit-wid-con" ><div  class="elementskit-testimonial-slider ekit_testimonial_style_6 slick-slider arrow_inside " data-config="{&quot;rtl&quot;:false,&quot;arrows&quot;:false,&quot;dots&quot;:false,&quot;pauseOnHover&quot;:true,&quot;autoplay&quot;:true,&quot;speed&quot;:1000,&quot;slidesPerGroup&quot;:3,&quot;slidesPerView&quot;:3,&quot;loop&quot;:false,&quot;breakpoints&quot;:{&quot;320&quot;:{&quot;slidesPerView&quot;:1,&quot;slidesPerGroup&quot;:1},&quot;768&quot;:{&quot;slidesPerView&quot;:2,&quot;slidesPerGroup&quot;:1},&quot;1024&quot;:{&quot;slidesPerView&quot;:3,&quot;slidesPerGroup&quot;:3}}}">
	<div class="swiper-container">
		<div class="slick-list swiper-wrapper">
							<div class="swiper-slide">
					<div class="slick-slide">
						<div class="elementskit-single-testimonial-slider elementskit-testimonial-slider-block-style elementskit-testimonial-slider-block-style-three elementor-repeater-item-73d8a9b" >
														<div class="elementskit-watermark-icon elementskit-icon-content  commentor-badge ">
								<i aria-hidden="true" class="icon icon-quote1"></i>							</div>
																					<div class="elementskit-commentor-bio ">
								<div class="elementkit-commentor-details">
								<div class="elementskit-commentor-image ekit-testimonial--avatar">
								<img width="1080" height="1080" src="wp-content/uploads/sites/26/2021/12/portrait-of-handsome-man-with-beard.jpg" class="attachment-full size-full" alt="Portrait of handsome man with beard" loading="lazy" sizes="(max-width: 1080px) 100vw, 1080px" />										
								</div>
								</div>
							</div>
							
					<div class="elementskit-profile-info">
					<strong class="elementskit-author-name">Calvin D Martinez</strong>
					<span class="elementskit-author-des">Founder Lokamart</span>
					</div>
					<div class="elementskit-commentor-content">
					<ul class="elementskit-stars">
					<li><a><i class="eicon-star active"></i></a></li>
					<li><a><i class="eicon-star active"></i></a></li>
					<li><a><i class="eicon-star active"></i></a></li>
					<li><a><i class="eicon-star active"></i></a></li>
					<li><a><i class="eicon-star active"></i></a></li>
					</ul>
					<p>Id felis ut senectus platea cubilia. Ac litora pretium pellentesque elementum lacus sem arcu justo curae. Mus fermentum habitant conubia pede consectetuer.</p>
					</div>
					</div>
					</div>
				</div>
				<div class="swiper-slide">
					<div class="slick-slide">
						<div class="elementskit-single-testimonial-slider elementskit-testimonial-slider-block-style elementskit-testimonial-slider-block-style-three elementor-repeater-item-af9b28e" >
														<div class="elementskit-watermark-icon elementskit-icon-content  commentor-badge ">
								<i aria-hidden="true" class="icon icon-quote1"></i>							
					</div>
					<div class="elementskit-commentor-bio ">
								<div class="elementkit-commentor-details">
										<div class="elementskit-commentor-image ekit-testimonial--avatar">
					<img width="1080" height="1080" src="wp-content/uploads/sites/26/2021/12/portrait-of-handsome-man-with-beard.jpg" class="attachment-full size-full" alt="Portrait of handsome man with beard" loading="lazy" srcset="wp-content/uploads/sites/26/2021/12/portrait-of-handsome-man-with-beard.jpg 1080w, wp-content/uploads/sites/26/2021/12/portrait-of-handsome-man-with-beard-300x300.jpg 300w, wp-content/uploads/sites/26/2021/12/portrait-of-handsome-man-with-beard-1024x1024.jpg 1024w, wp-content/uploads/sites/26/2021/12/portrait-of-handsome-man-with-beard-150x150.jpg 150w, wp-content/uploads/sites/26/2021/12/portrait-of-handsome-man-with-beard-768x768.jpg 768w, wp-content/uploads/sites/26/2021/12/portrait-of-handsome-man-with-beard-1536x1536.jpg 1536w, wp-content/uploads/sites/26/2021/12/portrait-of-handsome-man-with-beard-800x800.jpg 800w" sizes="(max-width: 1080px) 100vw, 1080px" />										</div>
								</div>
							</div>
					<div class="elementskit-profile-info">
					<strong class="elementskit-author-name">Calvin D Martinez</strong>
					<span class="elementskit-author-des">Founder Lokamart</span>
					</div>
					<div class="elementskit-commentor-content">
					<ul class="elementskit-stars">
					<li><a><i class="eicon-star active"></i></a></li>
					<li><a><i class="eicon-star active"></i></a></li>
					<li><a><i class="eicon-star active"></i></a></li>
					<li><a><i class="eicon-star active"></i></a></li>
					<li><a><i class="eicon-star active"></i></a></li>
					</ul>
					<p>Id felis ut senectus platea cubilia. Ac litora pretium pellentesque elementum lacus sem arcu justo curae. Mus fermentum habitant conubia pede consectetuer.</p>
					</div>
					</div>
					</div>
				</div>
							<div class="swiper-slide">
					<div class="slick-slide">
						<div class="elementskit-single-testimonial-slider elementskit-testimonial-slider-block-style elementskit-testimonial-slider-block-style-three elementor-repeater-item-b98c9d0" >
					<div class="elementskit-watermark-icon elementskit-icon-content  commentor-badge ">
								<i aria-hidden="true" class="icon icon-quote1"></i>							
					</div>
							<div class="elementskit-commentor-bio ">
								<div class="elementkit-commentor-details">
										<div class="elementskit-commentor-image ekit-testimonial--avatar">
											<img width="1080" height="1080" src="wp-content/uploads/sites/26/2021/12/portrait-of-handsome-man-with-beard.jpg" class="attachment-full size-full" alt="Portrait of handsome man with beard" loading="lazy" srcset="wp-content/uploads/sites/26/2021/12/portrait-of-handsome-man-with-beard.jpg 1080w, wp-content/uploads/sites/26/2021/12/portrait-of-handsome-man-with-beard-300x300.jpg 300w, wp-content/uploads/sites/26/2021/12/portrait-of-handsome-man-with-beard-1024x1024.jpg 1024w, wp-content/uploads/sites/26/2021/12/portrait-of-handsome-man-with-beard-150x150.jpg 150w, wp-content/uploads/sites/26/2021/12/portrait-of-handsome-man-with-beard-768x768.jpg 768w, wp-content/uploads/sites/26/2021/12/portrait-of-handsome-man-with-beard-1536x1536.jpg 1536w, wp-content/uploads/sites/26/2021/12/portrait-of-handsome-man-with-beard-800x800.jpg 800w" sizes="(max-width: 1080px) 100vw, 1080px" />										</div>
								</div>
							</div>
							
						<div class="elementskit-profile-info">
						<strong class="elementskit-author-name">Calvin D Martinez</strong>
						<span class="elementskit-author-des">Founder Lokamart</span>	
						</div>
						<div class="elementskit-commentor-content">
						<ul class="elementskit-stars">
						<li><a><i class="eicon-star active"></i></a></li>
						<li><a><i class="eicon-star active"></i></a></li>
						<li><a><i class="eicon-star active"></i></a></li>
						<li><a><i class="eicon-star active"></i></a></li>
						<li><a><i class="eicon-star active"></i></a></li>
						</ul>
						<p>Id felis ut senectus platea cubilia. Ac litora pretium pellentesque elementum lacus sem arcu justo curae. Mus fermentum habitant conubia pede consectetuer.</p>
						</div>
						</div>
					</div>
				</div>
					</div>
	</div>
	<ul class="slick-dots swiper-pagination swiper-pagination-clickable swiper-pagination-bullets"></ul>
	</div>
	</div>		
	</div>
	</div>
	</div>
	</div>
	</div>
	</section>
	</div>
	
										
		<?php
			include("footer2.php");
			include ("js2.php");
		?>

</body>

</html>
