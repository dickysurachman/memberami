<div data-elementor-type="header" data-elementor-id="35" class="elementor elementor-35 elementor-location-header">
<section class="elementor-section elementor-top-section elementor-element elementor-element-4a4e509 elementor-section-content-middle elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="4a4e509" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-4e61abe" data-id="4e61abe" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-50e0521 elementor-widget elementor-widget-image" data-id="50e0521" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
			<style>
.elementor-widget-image{text-align:center}.elementor-widget-image a{display:inline-block}.elementor-widget-image a img[src$=".svg"]{width:48px}.elementor-widget-image img{vertical-align:middle;display:inline-block}</style>													<a href="https://show.moxcreative.com/centrix">
							<img src="wp-content/uploads/sites/26/elementor/thumbs/logo_centrix-ph24g8f6q4xsil78fpjtw9i3j2jsh5pf1sdbcs5af4.png" title="logo_centrix" alt="logo_centrix" />								</a>
															</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-922b1f2" data-id="922b1f2" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-d39c7fa elementor-nav-menu__align-right elementor-nav-menu--stretch elementor-nav-menu--dropdown-tablet elementor-nav-menu__text-align-aside elementor-nav-menu--toggle elementor-nav-menu--burger elementor-widget elementor-widget-nav-menu" data-id="d39c7fa" data-element_type="widget" data-settings="{&quot;submenu_icon&quot;:{&quot;value&quot;:&quot;&lt;i class=\&quot;fas fa-chevron-down\&quot;&gt;&lt;\/i&gt;&quot;,&quot;library&quot;:&quot;fa-solid&quot;},&quot;full_width&quot;:&quot;stretch&quot;,&quot;layout&quot;:&quot;horizontal&quot;,&quot;toggle&quot;:&quot;burger&quot;}" data-widget_type="nav-menu.default">
				<div class="elementor-widget-container">
						<nav migration_allowed="1" migrated="0" role="navigation" class="elementor-nav-menu--main elementor-nav-menu__container elementor-nav-menu--layout-horizontal e--pointer-none">
				<ul id="menu-1-d39c7fa" class="elementor-nav-menu"><li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-22"><a href="homepage/index.html" class="elementor-item">Home</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-23"><a href="about-us/index.html" class="elementor-item">About us</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom current-menu-ancestor current-menu-parent menu-item-has-children menu-item-25"><a href="services/index.html" class="elementor-item">Services</a>
<ul class="sub-menu elementor-nav-menu--dropdown">
	<li class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item menu-item-26"><a href="index.html" aria-current="page" class="elementor-sub-item elementor-item-active">Machine Vision</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item menu-item-26"><a href="index.html" aria-current="page" class="elementor-sub-item elementor-item-active">Mobile Robot</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-27"><a href="project/index.html" class="elementor-item">Project</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-32"><a href="site/contact.html" class="elementor-item">Contact Us</a></li>
<!--<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-34"><a href="#" class="elementor-item elementor-item-anchor">Page</a>
<ul class="sub-menu elementor-nav-menu--dropdown">
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-24"><a href="leadership/index.html" class="elementor-sub-item">Team</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-28"><a href="help-center/index.html" class="elementor-sub-item">Help Center</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-29"><a href="pricing-plan/index.html" class="elementor-sub-item">Pricing Plan</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-33"><a href="https://show.moxcreative.com/centrix/?elementor_library=centrix-v1-error-404" class="elementor-sub-item">Error 404</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-30"><a href="https://show.moxcreative.com/centrix/?elementor_library=centrix-v1-archive" class="elementor-sub-item">Blog</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-31"><a href="https://show.moxcreative.com/centrix/2021/12/05/goemotions-a-dataset-for-fine-grained-emotion-classification/" class="elementor-sub-item">Single Post</a></li>
</ul>
</li>-->
</ul>			</nav>
					<div class="elementor-menu-toggle" role="button" tabindex="0" aria-label="Menu Toggle" aria-expanded="false">
			<i aria-hidden="true" role="presentation" class="elementor-menu-toggle__icon--open eicon-menu-bar"></i><i aria-hidden="true" role="presentation" class="elementor-menu-toggle__icon--close eicon-close"></i>			<span class="elementor-screen-only">Menu</span>
		</div>
			<nav class="elementor-nav-menu--dropdown elementor-nav-menu__container" role="navigation" aria-hidden="true">
				<ul id="menu-2-d39c7fa" class="elementor-nav-menu"><li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-22"><a href="homepage/index.html" class="elementor-item" tabindex="-1">Home</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-23"><a href="about-us/index.html" class="elementor-item" tabindex="-1">About us</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom current-menu-ancestor current-menu-parent menu-item-has-children menu-item-25"><a href="services/index.html" class="elementor-item" tabindex="-1">Services</a>
<ul class="sub-menu elementor-nav-menu--dropdown">
	<li class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item menu-item-26"><a href="index.html" aria-current="page" class="elementor-sub-item elementor-item-active" tabindex="-1">Machine Vision</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item menu-item-26"><a href="index.html" aria-current="page" class="elementor-sub-item elementor-item-active" tabindex="-1">Mobile Robot</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-27"><a href="project/index.html" class="elementor-item" tabindex="-1">Project</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-32"><a href="site/contact.html" class="elementor-item" tabindex="-1">Contact Us</a></li>
<!--<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-34"><a href="#" class="elementor-item elementor-item-anchor" tabindex="-1">Page</a>
<ul class="sub-menu elementor-nav-menu--dropdown">
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-24"><a href="leadership/index.html" class="elementor-sub-item" tabindex="-1">Team</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-28"><a href="help-center/index.html" class="elementor-sub-item" tabindex="-1">Help Center</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-29"><a href="pricing-plan/index.html" class="elementor-sub-item" tabindex="-1">Pricing Plan</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-33"><a href="https://show.moxcreative.com/centrix/?elementor_library=centrix-v1-error-404" class="elementor-sub-item" tabindex="-1">Error 404</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-30"><a href="https://show.moxcreative.com/centrix/?elementor_library=centrix-v1-archive" class="elementor-sub-item" tabindex="-1">Blog</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-31"><a href="https://show.moxcreative.com/centrix/2021/12/05/goemotions-a-dataset-for-fine-grained-emotion-classification/" class="elementor-sub-item" tabindex="-1">Single Post</a></li>
</ul>
</li>-->
</ul>			</nav>
				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-c9f1b73 elementor-hidden-mobile" data-id="c9f1b73" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-a748dc9 elementor-align-right elementor-widget elementor-widget-button" data-id="a748dc9" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a href="site/login.html" class="elementor-button-link elementor-button elementor-size-sm" role="button">
						<span class="elementor-button-content-wrapper">
						<span class="elementor-button-text">Get Started</span>
		</span>
					</a>
		</div>
				</div>
				</div>
					</div>
		</div>
							</div>
		</section>
		</div>