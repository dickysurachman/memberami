<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "project".
 *
 * @property int $id
 * @property string $nama
 * @property int $id_costumer
 * @property string $tanggal
 * @property string $deskripsi
 * @property float $jumlah
 * @property int $status
 * @property string $tanggal_deadline
 */
class Project extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'project';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['nama', 'id_costumer', 'tanggal', 'deskripsi', 'jumlah', 'tanggal_deadline'], 'required'],
            [['id_costumer', 'status','id_user'], 'integer'],
            [['tanggal', 'tanggal_deadline'], 'safe'],
            [['deskripsi'], 'string'],
            [['jumlah'], 'number'],
            [['nama'], 'string', 'max' => 150],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'nama' => 'Nama Project',
            'id_costumer' => 'Costumer',
            'tanggal' => 'Tanggal Mulai',
            'deskripsi' => 'Deskripsi',
            'jumlah' => 'Jumlah',
            'status' => 'Status',
            'tanggal_deadline' => 'Tanggal Deadline',
        ];
    }
    public function getStatusnya(){
        if($this->status==0){
            return "On Progress";
        } else {
            return "Finish";
        }

    }
     public function getCostumer()
    {
        return $this->hasOne(Costumer::className(), ['id' => 'id_costumer']);
    }

      public function beforeSave($insert)
    {
        if (parent::beforeSave($insert)) {
            if($this->isNewRecord)   
            $this->id_user=Yii::$app->user->identity->id;
            return true;
        } else {
            
            return false;
        }
    }
}
