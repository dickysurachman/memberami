<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "training".
 *
 * @property int $id
 * @property string $tanggal_r
 * @property int $status
 * @property string $keterangan
 * @property string $nama
 */
class Training extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'training';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['tanggal_r', 'keterangan', 'nama'], 'required'],
            [['tanggal_r'], 'safe'],
            [['status','id_user'], 'integer'],
            [['keterangan'], 'string'],
            [['nama'], 'string', 'max' => 100],
        ];
    }

    public function getStatusnya(){
        if($this->status==0){
            return "On Request";
        } else {
            return "Approved";
        }

    }
    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'tanggal_r' => 'Tanggal Request',
            'status' => 'Status',
            'keterangan' => 'Keterangan',
            'nama' => 'Subject',
            'id_user' => 'User',
        ];
    }
    public function beforeSave($insert)
    {
        if (parent::beforeSave($insert)) {
            if($this->isNewRecord)   
            $this->id_user=Yii::$app->user->identity->id;
            return true;
        } else {
            
            return false;
        }
    }
}
