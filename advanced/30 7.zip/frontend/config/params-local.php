<?php

return [
		 'bsVersion' => '4.x',
     'bsDependencyEnabled' => false, // this will not load Bootstrap CSS and JS for all Krajee extensions
];
