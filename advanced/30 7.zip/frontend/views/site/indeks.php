<?php 
if(isset($hasil)) echo $hasil->konten;

?>