<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Costumer */
?>
<div class="costumer-update">

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
