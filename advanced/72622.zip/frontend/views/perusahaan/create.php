<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\Perusahaan */

?>
<div class="perusahaan-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
