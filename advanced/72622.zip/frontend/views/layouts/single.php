<!doctype html>
<html lang="en-US">

<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>

	<?php 
		include("head2.php")
	?>
</head>
<body class="envato_tk_templates-template envato_tk_templates-template-elementor_header_footer single single-envato_tk_templates postid-922 qodef-qi--no-touch qi-addons-for-elementor-1.5.3 elementor-default elementor-template-full-width elementor-kit-7 elementor-page elementor-page-922">

		<?php

			include ("header.php");
			//echo $hasil->konten;
		?>
		<div  class="elementor elementor-922">
	<section class="elementor-section elementor-top-section elementor-element elementor-element-1f042ce elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="51c084d" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
		<?= $content ?>
		</section>
	</div>
		<?php
			include("footer.php");
			include ("js.php");
		?>

</body>

</html>
