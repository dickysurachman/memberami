<?php

return [
	 'bsVersion' => '4.x',
     'bsDependencyEnabled' => false, // this will not load Bootstrap CSS and JS for all Krajee extensions

];
/*
'params' => [
    // you need to ensure you load the Bootstrap CSS/JS manually in your view layout before Krajee CSS/JS assets
    //
    // other params settings below
    // 'bsVersion' => '5.x',
    // 'adminEmail' => 'admin@example.com'
]*/