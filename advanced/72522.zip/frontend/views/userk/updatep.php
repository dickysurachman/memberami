<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\user */
?>
<div class="user-update">

    <?= $this->render('_formp', [
        'model' => $model,
    ]) ?>

</div>
